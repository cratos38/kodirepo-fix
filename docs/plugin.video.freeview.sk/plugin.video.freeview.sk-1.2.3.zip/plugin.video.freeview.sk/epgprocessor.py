# -*- coding: utf-8 -*-
# Module: epgprocessor
# Author: cache-sk
# Modified by: cratos38
# License: MIT https://opensource.org/licenses/MIT

"""
EPG Processor for Freeview.sk
Fixed: Changed EPG source from m7cz.solocoo.tv to iptv-epg.org
Reason: m7cz.solocoo.tv no longer responds, causing empty EPG
"""

import os
import gzip
import xml.etree.ElementTree as ET
from datetime import datetime
import xbmc
import xbmcaddon
import xbmcvfs

# EPG Source - FIXED: Changed to working source
EPG_URL = 'https://iptv-epg.org/files/epg-cz.xml.gz'

# Original non-working source (kept for reference):
# EPG_URL_OLD = 'https://m7cz.solocoo.tv/m7cziphone'

_addon = xbmcaddon.Addon()
_addon_path = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))

def log(msg):
    """Log messages to Kodi log"""
    xbmc.log('[FREEVIEW EPG] %s' % msg, xbmc.LOGINFO)

def download_epg():
    """
    Download EPG data from iptv-epg.org
    Returns: Path to downloaded file or None if failed
    """
    import urllib.request
    
    log('Downloading EPG from: %s' % EPG_URL)
    
    try:
        # Download the gzipped EPG file
        epg_file = os.path.join(_addon_path, 'epg-cz.xml.gz')
        urllib.request.urlretrieve(EPG_URL, epg_file)
        
        log('EPG downloaded successfully: %s' % epg_file)
        return epg_file
        
    except Exception as e:
        log('ERROR downloading EPG: %s' % str(e))
        return None

def extract_epg(gz_file):
    """
    Extract gzipped EPG file
    Returns: Path to extracted XML or None if failed
    """
    try:
        xml_file = gz_file.replace('.gz', '')
        
        log('Extracting EPG: %s -> %s' % (gz_file, xml_file))
        
        with gzip.open(gz_file, 'rb') as f_in:
            with open(xml_file, 'wb') as f_out:
                f_out.write(f_in.read())
        
        log('EPG extracted successfully')
        return xml_file
        
    except Exception as e:
        log('ERROR extracting EPG: %s' % str(e))
        return None

def parse_epg(xml_file):
    """
    Parse EPG XML and return programme data
    Returns: Dictionary of {channel_id: [programmes]}
    """
    try:
        log('Parsing EPG XML: %s' % xml_file)
        
        tree = ET.parse(xml_file)
        root = tree.getroot()
        
        epg_data = {}
        
        # Parse programmes
        for programme in root.findall('programme'):
            channel = programme.get('channel')
            if channel not in epg_data:
                epg_data[channel] = []
            
            epg_data[channel].append({
                'start': programme.get('start'),
                'stop': programme.get('stop'),
                'title': programme.find('title').text if programme.find('title') is not None else '',
                'desc': programme.find('desc').text if programme.find('desc') is not None else ''
            })
        
        log('EPG parsed: %d channels, %d programmes' % (len(epg_data), sum(len(p) for p in epg_data.values())))
        return epg_data
        
    except Exception as e:
        log('ERROR parsing EPG: %s' % str(e))
        return {}

def generate_xmltv(epg_data, output_file):
    """
    Generate XMLTV file for Kodi PVR
    """
    try:
        log('Generating XMLTV: %s' % output_file)
        
        root = ET.Element('tv')
        root.set('generator-info-name', 'Freeview.sk EPG Processor')
        root.set('generator-info-url', 'https://github.com/cratos38/plugin.video.freeview.sk')
        
        # Add channels
        channels_added = set()
        for channel_id in epg_data.keys():
            if channel_id not in channels_added:
                channel_elem = ET.SubElement(root, 'channel')
                channel_elem.set('id', channel_id)
                
                display_name = ET.SubElement(channel_elem, 'display-name')
                display_name.text = channel_id
                
                channels_added.add(channel_id)
        
        # Add programmes
        for channel_id, programmes in epg_data.items():
            for prog in programmes:
                programme_elem = ET.SubElement(root, 'programme')
                programme_elem.set('channel', channel_id)
                programme_elem.set('start', prog['start'])
                programme_elem.set('stop', prog['stop'])
                
                title_elem = ET.SubElement(programme_elem, 'title')
                title_elem.set('lang', 'cs')
                title_elem.text = prog['title']
                
                if prog['desc']:
                    desc_elem = ET.SubElement(programme_elem, 'desc')
                    desc_elem.set('lang', 'cs')
                    desc_elem.text = prog['desc']
        
        # Write XML
        tree = ET.ElementTree(root)
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        
        log('XMLTV generated successfully: %s' % output_file)
        return True
        
    except Exception as e:
        log('ERROR generating XMLTV: %s' % str(e))
        return False

def update_epg():
    """
    Main function to update EPG
    Called by service.py or manually
    """
    log('========================================')
    log('EPG UPDATE STARTED')
    log('Source: %s' % EPG_URL)
    log('========================================')
    
    # Download
    gz_file = download_epg()
    if not gz_file:
        log('EPG update FAILED: Download error')
        return False
    
    # Extract
    xml_file = extract_epg(gz_file)
    if not xml_file:
        log('EPG update FAILED: Extraction error')
        return False
    
    # Parse
    epg_data = parse_epg(xml_file)
    if not epg_data:
        log('EPG update FAILED: Parsing error')
        return False
    
    # Generate XMLTV
    output_file = os.path.join(_addon_path, 'epg.xml')
    if not generate_xmltv(epg_data, output_file):
        log('EPG update FAILED: Generation error')
        return False
    
    # Cleanup
    try:
        os.remove(gz_file)
        os.remove(xml_file)
    except:
        pass
    
    log('========================================')
    log('EPG UPDATE COMPLETED SUCCESSFULLY')
    log('Output: %s' % output_file)
    log('========================================')
    
    return True

if __name__ == '__main__':
    update_epg()
