<?php
	$USERNAME = "";
	$PASSWORD = "";
	
	$CHANNELS = array(
		"prima" => array(
			"https://prima.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p111013/play"
		),
		"cool" => array(
			"https://cool.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p111014/play"
		),
		"max" => array(
			"https://max.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p111017/play"
		),
		"krimi" => array(
			"https://krimi.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p432829/play"
		),
		"love" => array(
			"https://love.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p111016/play"
		),
		"zoom" => array(
			"https://zoom.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p111015/play"
		),
		"show" => array(
			"https://show.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p899572/play"
		),
		"star" => array(
			"https://star.iprima.cz/",
			"https://api.play-backend.iprima.cz/api/v1//products/id-p846043/play"
		)
	);
	
	$UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0';
?>